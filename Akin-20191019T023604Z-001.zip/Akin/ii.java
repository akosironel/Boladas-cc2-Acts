public class {
  public static void main(String [] args){
    System.out.println("J FFFFF");
    System.out.println("J F");
    System.out.println("J FFF");
    System.out.println("J F");
    System.out.println("FFFFF J");
    
    }
}