import java.util.Scanner;
public class Ron{
  public static void main (String [] args){
    Scanner sc = new Scanner(System.in);
      try{
    System.out.print("Enter a number from 0 to 9: ");
    int fnum = sc.nextInt();
    int snum = sc.nextInt();
    int tnum = sc.nextInt();
    int frnum = sc.nextInt();
    int ffnum = sc.nextInt();
    int sxnum = sc.nextInt();
   
    if(fnum >=0 && fnum <10 && snum >=0 && snum <10 && tnum >=0 && tnum <10 && frnum >=0 && frnum <10 && ffnum >=0 && ffnum <10 && sxnum >=0 && sxnum <10){
      for(int i = 1; i <=9; i++){
        for (int l = 0; l <=9;l++ ){
          if(i ==fnum || l == fnum){
            continue;
          }else if(i == snum || l == snum){
            continue;
          }else if(i == tnum || l == tnum){
            continue;
          }else if(i == frnum || l == frnum){
            continue;
          }else if(i == ffnum || l == ffnum){
            continue;
          }else if(i == sxnum || l == sxnum){
            continue;
          }
          else{
            System.out.println(i+""+l);
          }
        }
      }
    }else {
      System.out.print("Error");
    }
    } catch (Exception e){
      System.out.println("Invalid inoyt");
    }
     
   }
    
    
  }
 