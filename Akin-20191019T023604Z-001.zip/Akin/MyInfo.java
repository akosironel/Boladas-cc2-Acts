public class MyInfo{
  public static void main(String [] args){
    System.out.println("Boladas,Ronel.P");
    System.out.println("18");
    System.out.println("Bs Computer Science");
    System.out.println("#51 Upper Rock Q.M");
    }
}