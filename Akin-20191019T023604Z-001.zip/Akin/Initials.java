import javax.swing.*;
public class Initials{
  public static void main(String [] args){
    String msg=JOptionPane.showInputDialog("Enter your first inital name");
    char A =msg.charAt(0);
    String msg2=JOptionPane.showInputDialog("Enter your Middle Initial name");
     char B =msg2.charAt(0);
    String msg3=JOptionPane.showInputDialog("Enter your last  Initial name");
     char C =msg3.charAt(0);
    JOptionPane.showMessageDialog(null,A+"."+B+"."+C);
    }
  }