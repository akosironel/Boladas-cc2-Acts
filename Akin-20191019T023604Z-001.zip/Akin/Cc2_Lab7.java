import java.io.*;
public class Cc2_Lab7{
  public static void main (String [] args)throws IOException{
   BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
    String A ="A";
   www String B ="B";
    String D ="D";
    String C ="C";
    String F ="F";
    int grade = 0;
    
    System.out.print("Enter A Number: ");
     grade = Integer.parseInt(br.readLine());
    if(grade >=79 && grade <83){
      System.out.println("C+");
    } 
    else if(grade >=92 && grade <=100){
      System.out.println("A");
    }
    else if(grade >=83 && grade <=86){
      System.out.println("B");
    }
    else if(grade <=74 && grade <=70){
      System.out.println("D");
    }
    else if (grade >=75 && grade <=78){
      System.out.println("C");
    }
    else if (grade >=87 && grade <=91){
      System.out.println("B+");
    }
    else{
      System.out.println("F");
    }
    
    
    }
  
  
  }