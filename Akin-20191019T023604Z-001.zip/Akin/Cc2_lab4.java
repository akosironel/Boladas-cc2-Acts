  import java.util.Scanner;
public class Cc2_Lab4{
  public static void main(String [] args){
    Scanner sc = new Scanner (System.in);
    String name = sc.nextLine();
    int age = sc.nextInt();
    
    if(name.equals("jhim") || name.equals("Ethan")){
       
    
        if(age>4 && age<11  ){
          System.out.println("Hamster,Dog");
        }
        else if(age >10 && age<16){
          System.out.println("Spider,Dog");
        
        }
        else if(age>15 && age <21){
          System.out.println("Dog,Snake");
          
        }
        else if( age >20){
          System.out.println("No pets,Not Interested");
        }
          }
        else if(name.equals("Sally") || name.equals("Ethan")){
          
        
        if(age >4 && age <11){
          System.out.println("Hamster,Cat");
        }
        else if(age >10 && age <16){
          System.out.println("Cat,Rabbit");
        }
        else if(age >15 && age <21){
          System.out.println("cat");
        }
        else if(age <20){
        
        }
        else {
          System.out.println("No pets,Not interested");
        }}
  }
    }