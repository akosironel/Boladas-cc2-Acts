import java.util.Scanner;
public class Ron2{
  public static void main (String [] args){
   Scanner sc = new Scanner(System.in);
   
   for (int i = 11; i <=99; i++) {
    if(){
      continue;
    }
    if(){
      continue;
    }else{
      System.out.println(i);
    }
  
  }
 } 
}