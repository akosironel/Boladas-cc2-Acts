public class VariablesAndDataTypes{
  public static void main(String [] args){
    char a = 'A';
    long hour = 24;
    short day = 7;
    byte week = 4;
    int month = 12;
    float temp= 16;
    double celc = 23.5;
    String Temp = "The temperature in baguio city has warned thoroughout the years";
    boolean hi = true;
    if(hi == true){
      System.out.println(Temp +"\n "+
      a +"recent news artilce stated that the city has been averaging" + temp +
      "degrees celsius at dawn and" + celc + "at noon" +
      "  regarless,low landers still feel cold" + hour + "hours a day," + day +
       "day a week," + week + "week pero month and " + month + "months each year");
      
    }
    else{
      System.out.println("The boolean was changed to False value");
    }
  }
}