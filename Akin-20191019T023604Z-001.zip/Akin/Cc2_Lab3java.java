  public class Cc2_Lab3java{
  public static void main (String [] args){
  char r='R';
  char o='O';
  char n='N';
  char e='E';
  char l='!';
  long z=r;
  long x=o;
  long c=n;
  long v=e;
  long b=l;
  
  System.out.println("R-" + z);
  System.out.println("O-" + x);
  System.out.println("N-" + c);
  System.out.println("E-" + v);
  System.out.println("!-"+ b);
  System.out.println(r+""+o+""+n+""+e+""+l);
  
  long A= z+x+c+v+b;
  long B= z*x*c*v*b;
  long C= (z+x+c+v+b)/5;
  long D= B%C;
  
  System.out.println("Sum: " + A);
  System.out.println("Product: " + B);
  System.out.println("Average: " + C);
  System.out.println("Remainder:" + D);
  
  }
}